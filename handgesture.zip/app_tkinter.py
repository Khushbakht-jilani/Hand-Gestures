import cv2
import numpy as np
import mediapipe as mp
from tensorflow.keras.models import load_model

# ========================
# Load Trained Model
# ========================
model = load_model("sign_language_model.h5")

# Check model input
print("Model Input Shape:", model.input_shape)

# Labels (Sign Language MNIST ke liye A-Z except J and Z)
labels = [chr(i) for i in range(65, 91) if i not in [74, 90]]

# ========================
# Mediapipe Hand Detection
# ========================
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

# ========================
# Camera Setup
# ========================
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print(" Camera not opened!")
    exit()

print(" Camera opened successfully!")

while True:
    ret, frame = cap.read()
    if not ret:
        print("Frame not captured!")
        break

    # Flip frame for natural view
    frame = cv2.flip(frame, 1)
    h, w, c = frame.shape
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb_frame)

    if result.multi_hand_landmarks:
        for hand_landmarks in result.multi_hand_landmarks:
            # Bounding box extract
            x_min = int(min([lm.x for lm in hand_landmarks.landmark]) * w)
            y_min = int(min([lm.y for lm in hand_landmarks.landmark]) * h)
            x_max = int(max([lm.x for lm in hand_landmarks.landmark]) * w)
            y_max = int(max([lm.y for lm in hand_landmarks.landmark]) * h)

            # Crop hand region
            hand_img = frame[y_min:y_max, x_min:x_max]
            if hand_img.size > 0:
                try:
                    hand_img = cv2.cvtColor(hand_img, cv2.COLOR_BGR2GRAY)
                    hand_img = cv2.resize(hand_img, (28, 28))  # dataset size
                    hand_img = hand_img.reshape(1, 28, 28, 1) / 255.0

                    # Predict gesture
                    prediction = model.predict(hand_img, verbose=0)
                    class_id = np.argmax(prediction)
                    gesture = labels[class_id]

                    # Show prediction
                    cv2.putText(frame, gesture, (x_min, y_min - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 2)
                except Exception as e:
                    print("⚠️ Error in prediction:", e)

            # Draw hand landmarks
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

    cv2.imshow("Hand Gesture Recognition", frame)

    # Exit on 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
