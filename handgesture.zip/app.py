import streamlit as st
import cv2
import numpy as np
from tensorflow.keras.models import load_model
import mediapipe as mp

st.title("✋ Hand Gesture Recognition App")
st.markdown("Real-time hand sign detection using CNN + Mediapipe + OpenCV")

# Load Model
model = load_model("sign_language_model.h5")

# Labels (A-Z without J and Z because ASL uses motion for them)
labels = [chr(i) for i in range(65, 91) if i not in [74, 90]]

# Checkbox to start camera
run = st.checkbox("Start Webcam")

# Camera + Mediapipe Setup
if run:
    cap = cv2.VideoCapture(0)
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
    mp_draw = mp.solutions.drawing_utils

    FRAME_WINDOW = st.image([])

    while run:
        ret, frame = cap.read()
        if not ret:
            st.write("⚠️ Camera not detected")
            break

        frame = cv2.flip(frame, 1)
        h, w, c = frame.shape
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb_frame)

        if result.multi_hand_landmarks:
            for hand_landmarks in result.multi_hand_landmarks:
                x_min = int(min([lm.x for lm in hand_landmarks.landmark]) * w)
                y_min = int(min([lm.y for lm in hand_landmarks.landmark]) * h)
                x_max = int(max([lm.x for lm in hand_landmarks.landmark]) * w)
                y_max = int(max([lm.y for lm in hand_landmarks.landmark]) * h)

                # Crop Hand Region
                hand_img = frame[y_min:y_max, x_min:x_max]
                if hand_img.size > 0:
                    hand_img = cv2.cvtColor(hand_img, cv2.COLOR_BGR2GRAY)
                    hand_img = cv2.resize(hand_img, (28, 28))
                    hand_img = hand_img.reshape(1, 28, 28, 1) / 255.0

                    prediction = model.predict(hand_img, verbose=0)
                    class_id = np.argmax(prediction)
                    gesture = labels[class_id]

                    cv2.putText(frame, gesture, (x_min, y_min - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 2)

                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        FRAME_WINDOW.image(frame, channels="BGR")
